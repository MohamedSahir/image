import { Component ,OnInit,Input,Output,EventEmitter} from '@angular/core';
import {CacheService, CacheStoragesEnum} from 'ng2-cache/ng2-cache';
@Component({
  selector: 'cache-component',
  templateUrl: './cache.component.html',
  providers: [ CacheService ]
})
export class CacheComponent implements OnInit {

cachedata;
    constructor(private _cacheService: CacheService) {}
    ngOnInit(){

     let x= "sahir";
    this._cacheService.set('key', [x], {maxAge: 1 * 60});

    let data: any|null = this._cacheService.get('key');

    console.log(data);
    this.cachedata =this._cacheService.get('key');
    setInterval(() =>this.cachedata=this._cacheService.get('key')  , 1*60);

    }


}