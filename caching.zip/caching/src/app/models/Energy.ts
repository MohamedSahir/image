export interface IEnergy{
    EnergyID:number;EnergyName:string;EnergyValue:number,
    //UserName:string;Password:string;
}