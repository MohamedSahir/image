import { Component ,OnInit,Input,Output,EventEmitter} from '@angular/core';



@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./app.component.css']
})
export class ParentComponent implements OnInit {
    @Input('master') passValueParent2Child: number;
    visitorss = 1000;

    title = 'I\'m a nested component';

newtitle="child to parent communication value";

    @Output() notify: EventEmitter<number> = new EventEmitter<number>();

    
    @Output() notifi: EventEmitter<number> = new EventEmitter<number>();


    @Output() onCategoryTitled = new EventEmitter<string>();





    onLodd(){
    this.notifi.emit(20);
        }

    onClick(){
    this.notify.emit(200);
    }

ngOnInit()
{
    this.onCategoryTitled.emit(this.newtitle);
    this.onLodd();
}

}