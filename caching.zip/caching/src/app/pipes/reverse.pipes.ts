// import { Pipe, PipeTransform } from '@angular/core';

// @Pipe({
//   name: 'reverse'
// })
// export class ReversePipe {
//   transform(arr) {
//     var copy = arr.slice();
//     return copy.reverse();
//   }
// }

import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'reverse'})
export class ReversePipe implements PipeTransform {
  transform(value: string): string {
    let newStr: string = "";
    for (var i = value.length - 1; i >= 0; i--) {
      newStr += value.charAt(i);
    }
    return newStr;
  }
}