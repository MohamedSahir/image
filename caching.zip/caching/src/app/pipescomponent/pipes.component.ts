import { Component ,OnInit,Input,Output,EventEmitter} from '@angular/core';

@Component({
  selector: 'simple-canvas',
  templateUrl: './pipes.component.html'
 
})
export class PipesComponent {
private longText;
private name;

    constructor() { 
        this.longText = 'Bacon ipsum dolor amet bacon t-bone tongue ball tip salami, flank capicola. Leberkas ribeye pork pork loin. Biltong porchetta picanha capicola tri-tip boudin. Tenderloin leberkas chicken, ham pig pork loin flank salami ham hock chuck meatball kevin. Meatloaf capicola landjaeger ground round ham hock ball tip boudin shank pork chop ribeye rump frankfurter turkey. Spare ribs short loin pork chop, biltong capicola shoulder pig drumstick pork porchetta brisket venison turducken sausage. Pig alcatra short loin jowl, prosciutto leberkas ham chuck.';
        this.name = "Mohamed sahir";
      }
}
