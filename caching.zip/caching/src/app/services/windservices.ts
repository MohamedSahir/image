import {Injectable} from '@angular/core';
import{Http,Response} from '@angular/http';
import{IEnergy} from '../models/Energy';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Observable } from 'rxjs';


@Injectable()
export class EnergyService{    
 constructor(private _http:Http)
    {     
    }   


    
    private _energyUrl ="../data/energys.json";


    //https://stackoverflow.com/questions/37052617/how-to-deal-with-http-status-codes-other-than-200-in-angular-2
   
    // getEnergyTestInterval(): Observable<IEnergy[]>{
    //     return this._http
    //       .get(this._energyUrl)
    //       .map((res: Response) => res.json()
    //     );
    //   }
   
   
    getEnergyTestInterval(): Observable<IEnergy[]>{
            return this._http
              .get(this._energyUrl)
              .map((res: Response) =>
              {

          if(res.status ==404){
           console.log("checked 404");
           return res.json()

           }else{

              res.json()
               } 
              }).catch(this.handleError);
          }
       
   
   
    getEnergy(): Observable <IEnergy[]>{   
            return this._http.get(this._energyUrl)
            .map((response:Response) =>  <IEnergy[]> response.json())
            .catch(this.handleError);
     }  




     
//     getEnergy(): Observable <IEnergy[]>{   
//         return Observable.interval(10000)
//             .flatMap(this._http.get(this._energyUrl)
//             .map((response:Response) =>  <IEnergy[]> response.json())
//             .catch(this.handleError));
//      }  


//      getData() : Observable<IEnergy[]> {
//         return Observable.interval(10000)
//                          .flatMap(this._http.get('url')
//                          .map((res:Response) => res.json()));
//     }
     

    // private handleError(error:Response){

    //     // alert("error occured");

    //     // console.log(error.status);
    //     //  if(error.status == 404){

    //     //     return Observable.throw("401");
    //     //  }
    //     //  else{
    //         return Observable.throw(error.json().error || "server error");
            
    //     //   }
        
        
    //     }



    private handleError(error:Response){
        alert(error);
        return Observable.throw(error);

        // return "404";
        }

}

































//private _energyUrl ="../data/energy.json";