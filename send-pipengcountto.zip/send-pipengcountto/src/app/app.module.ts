import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import {  
  NumberFormatPipe 
} from './numberformatpipe';


import { AppComponent } from './app.component';
import{RootParentComponent} from './rootparent.component';
import{ParentComponent} from './parent.component';
import { CountoModule }  from 'angular2-counto';

import { SimpleCanvasComponent } from './canvas/simplecanvas.component';




import { BikeInfoComponent } from './bikes/bike-info.component';
import { BikesComponent } from './bikes/bikes.component';
import { BikeService } from './bikes/bike.service';
import { PipesComponent } from './pipescomponent/pipes.component';

import { AppRoutingModule } from './app-routing.module';
import { EllipsisPipe } from './pipes/ellipsispipe';
import { ReversePipe } from './pipes/reverse.pipes';

@NgModule({  imports: [
  BrowserModule, FormsModule,
  HttpModule,AppRoutingModule, CountoModule
],
  declarations: [NumberFormatPipe,EllipsisPipe,ReversePipe,
    AppComponent,RootParentComponent,ParentComponent,SimpleCanvasComponent, BikesComponent ,BikeInfoComponent,PipesComponent 
  ],

  providers: [BikeService],
  bootstrap: [AppComponent],exports: [NumberFormatPipe],
})
export class AppModule { }
