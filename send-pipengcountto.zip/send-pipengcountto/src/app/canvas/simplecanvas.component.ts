import { Component ,OnInit,Input,Output,EventEmitter} from '@angular/core';

@Component({
  selector: 'simple-canvas',
  templateUrl: './simplecanvas.component.html'
 
})
export class SimpleCanvasComponent {


public c:any;

public y:any;
public x:any;

    ngAfterViewInit() {


    this.c= document.getElementById("myCanvas");
    let ctx =this.c.getContext("2d");
    ctx.beginPath();
    ctx.arc(95,50,40,0,2*Math.PI);
    ctx.stroke();


    this.x = document.getElementById("myCanvas1");
    var ctxx = this.x.getContext("2d");
    ctxx.font = "30px Arial";
    ctxx.strokeText("Hello World",10,50);




this.y= document.getElementById("myCanvas2");
    var ctxxx = this.y.getContext("2d");
    // Create gradient
    var grd = ctxxx.createLinearGradient(10,20,200,10);
    grd.addColorStop(0,"red");
    grd.addColorStop(1,"white");
    // Fill with gradient
    ctxxx.fillStyle = grd;
    ctxxx.fillRect(130,290,350,280);

}
}