import { Component ,OnInit,Output,EventEmitter,Pipe, PipeTransform } from '@angular/core';

import {  
  NumberFormatPipe 
} from './numberformatpipe';
declare var $:any;


@Component({
  selector: 'root-parent',
  templateUrl: './rootparent.component.html',
  styleUrls: ['./app.component.css']

})
export class RootParentComponent  implements OnInit{
  title = 'app';

   visitors = 1000;
    master = 100000;
childParentValuue;
    userNow(messages:number):void{
   console.log(messages);
   this.childParentValuue=messages;
    }



   onNotify(message:string):void {
    alert(message);
  }
  
// child -> parent communication
  catTitle:string;
      onCategoryTitled(cat_title: string) {
          console.log('EVENT recieved cat_title:', cat_title)
          this.catTitle = cat_title;
      }
  

   ngOnInit(){


//     $('#new').click(function(){

// alert('hi');

//     })
  }
  
}
